from distutils.core import setup

setup(
	name = 'MyKrazyListor',
	version = '1.0.4',
	py_modules = ['MyKrazyListor'],
	author = 'johny',
	author_email = 'jbshaik82@gmail.com',
	url = 'https://johnysthoughts.wordpress.com/',
	description = 'A simple list iterator'
)